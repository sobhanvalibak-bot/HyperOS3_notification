plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example.island"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.example.island"
        minSdk = 33
        targetSdk = 36
        // Always increases with each build, so a new build can be installed over the old one.
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.0"
    }
    signingConfigs {
        // Fixed key: every build is signed the same way, so updates install over the old app.
        create("shared") {
            storeFile = rootProject.file("island.keystore")
            storePassword = "island123"
            keyAlias = "island"
            keyPassword = "island123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("shared") }
        getByName("release") { signingConfig = signingConfigs.getByName("shared") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.06.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
}
