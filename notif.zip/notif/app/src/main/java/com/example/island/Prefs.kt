package com.example.island

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class P<T : Any>(private val sp: SharedPreferences, private val k: String, private val d: T) : ReadWriteProperty<Any?, T> {
    @Suppress("UNCHECKED_CAST")
    override fun getValue(thisRef: Any?, property: KProperty<*>): T = when (d) {
        is Boolean -> sp.getBoolean(k, d)
        is Int -> sp.getInt(k, d)
        else -> sp.getString(k, d as String)
    } as T

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        sp.edit().apply {
            when (value) {
                is Boolean -> putBoolean(k, value)
                is Int -> putInt(k, value)
                else -> putString(k, value as String)
            }
        }.apply()
    }
}

class Prefs(c: Context) {
    val sp: SharedPreferences = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    var enabled by P(sp, "enabled", true)          // island on/off
    var alwaysOn by P(sp, "alwaysOn", false)       // idle black bar always visible
    var hideOriginal by P(sp, "hideOriginal", true) // hide Telegram's own notification
    var bg by P(sp, "bg", 0xFF000000.toInt())
    var fg by P(sp, "fg", 0xFFFFFFFF.toInt())
    var idleText by P(sp, "idleText", "")
    var idleW by P(sp, "idleW", 110)
    var idleH by P(sp, "idleH", 30)
    var colW by P(sp, "colW", 190)
    var colH by P(sp, "colH", 36)
    var expW by P(sp, "expW", 340)
    var y by P(sp, "y", 8)
    var radius by P(sp, "radius", 28)
    var autoHide by P(sp, "autoHide", 6)
    var textSize by P(sp, "textSize", 14)
    var showChat by P(sp, "showChat", true)
    var showMsg by P(sp, "showMsg", true)
    var showBtns by P(sp, "showBtns", true)
    var idleBg by P(sp, "idleBg", 0xFF000000.toInt())
    var idleFg by P(sp, "idleFg", 0xFFFFFFFF.toInt())
    var idleBorderW by P(sp, "idleBorderW", 1)
    var idleBorderColor by P(sp, "idleBorderColor", 0xFF6B6B80.toInt())
    var idleRound by P(sp, "idleRound", 50)
    var exitNotif by P(sp, "exitNotif", true)      // test notification when leaving the app
    var showMsgs by P(sp, "showMsgs", true)        // messages / general notifications
    var showMedia by P(sp, "showMedia", true)      // now playing
    var showCalls by P(sp, "showCalls", true)      // incoming / ongoing calls
    var showProgress by P(sp, "showProgress", true) // downloads / progress
    var onlyAlerting by P(sp, "onlyAlerting", true) // skip silent notifications + respect Do Not Disturb
    var disabledApps by P(sp, "disabledApps", "")  // newline separated package names (all others are ON)
    var blockedTerms by P(sp, "blockedTerms", "")  // comma separated spoiler words

    fun appEnabled(pkg: String) = pkg !in disabledApps.split('\n')
    fun setApp(pkg: String, on: Boolean) {
        val s = disabledApps.split('\n').filter { it.isNotBlank() }.toMutableSet()
        if (on) s.remove(pkg) else s.add(pkg)
        disabledApps = s.joinToString("\n")
    }
    fun isBlocked(text: String): Boolean {
        val t = text.lowercase()
        return blockedTerms.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }.any { it in t }
    }
}
