package com.example.island

import android.app.Notification
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    var island: IslandController? = null
    private val prefsL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> island?.render() }

    companion object {
        @Volatile var inst: NotifService? = null
        val TG = setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus", "org.thunderdog.challegram")
    }

    override fun onListenerConnected() {
        inst = this
        island = IslandController(this).also { it.render() }
        Prefs(this).sp.registerOnSharedPreferenceChangeListener(prefsL)
    }

    override fun onListenerDisconnected() {
        Prefs(this).sp.unregisterOnSharedPreferenceChangeListener(prefsL)
        island?.remove(); island = null; inst = null
        runCatching { requestRebind(android.content.ComponentName(this, NotifService::class.java)) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in TG) return
        val n = sbn.notification
        val p = Prefs(this)
        if (!p.enabled || n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val isl = island ?: return
        // Only hide the original if our island can really be shown (otherwise you'd lose the message).
        if (p.hideOriginal && Settings.canDrawOverlays(this)) cancelNotification(sbn.key)
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val e = n.extras
        val chat = (e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: e.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: "Telegram"
        val last = e.getParcelableArray(Notification.EXTRA_MESSAGES, Bundle::class.java)?.lastOrNull()
        var text = (last?.getCharSequence("text") ?: e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        val sender = last?.getCharSequence("sender")?.toString()
        if (!sender.isNullOrBlank() && sender != chat) text = "$sender: $text"

        val icon = runCatching { n.getLargeIcon()?.loadDrawable(this) ?: n.smallIcon?.loadDrawable(this) }.getOrNull()
        val acts = n.actions?.toList().orEmpty()
        val reply = acts.firstOrNull { it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY && !it.remoteInputs.isNullOrEmpty() }
            ?: acts.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
        val read = acts.firstOrNull { it.semanticAction == Notification.Action.SEMANTIC_ACTION_MARK_AS_READ }
            ?: acts.firstOrNull { it.remoteInputs.isNullOrEmpty() }
        isl.show(Msg(chat, text, icon, reply, read))
    }
}
