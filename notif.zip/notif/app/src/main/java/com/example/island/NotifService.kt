package com.example.island

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads EVERY notification the phone posts (any app) and turns it into an island item.
 * Nothing is hard-coded per app: title / text / icon / app name / actions / progress / media
 * all come from the notification itself and from the phone's package info.
 */
class NotifService : NotificationListenerService() {
    var island: IslandController? = null
    private val prefsL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> island?.render() }

    companion object {
        @Volatile var inst: NotifService? = null
    }

    override fun onListenerConnected() {
        inst = this
        island = IslandController(this).also { it.render() }
        Prefs(this).sp.registerOnSharedPreferenceChangeListener(prefsL)
        // Pick up media / calls / downloads that are already running.
        runCatching { activeNotifications?.forEach { handle(it, initial = true) } }
    }

    override fun onListenerDisconnected() {
        Prefs(this).sp.unregisterOnSharedPreferenceChangeListener(prefsL)
        island?.remove(); island = null; inst = null
        runCatching { requestRebind(ComponentName(this, NotifService::class.java)) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = handle(sbn, initial = false)

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        island?.removeKey(sbn.key)
    }

    private fun handle(sbn: StatusBarNotification, initial: Boolean) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val p = Prefs(this)
        if (!p.enabled || !p.appEnabled(pkg)) return
        val isl = island ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val e = n.extras
        val ongoing = n.flags and Notification.FLAG_ONGOING_EVENT != 0
        val max = e.getInt(Notification.EXTRA_PROGRESS_MAX)
        val indet = e.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE)
        val isMedia = e.containsKey("android.mediaSession") ||
            e.getString(Notification.EXTRA_TEMPLATE)?.endsWith("MediaStyle") == true
        val kind = when {
            n.category == Notification.CATEGORY_CALL -> Kind.CALL
            isMedia -> Kind.MEDIA
            max > 0 || indet -> Kind.PROGRESS
            else -> Kind.MSG
        }

        // Per-type switches
        when (kind) {
            Kind.CALL -> if (!p.showCalls) return
            Kind.MEDIA -> if (!p.showMedia) return
            Kind.PROGRESS -> if (!p.showProgress) return
            Kind.MSG -> if (!p.showMsgs) return
        }

        val title = (e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: e.getCharSequence(Notification.EXTRA_TITLE))?.toString().orEmpty()
        val acts = n.actions?.toList().orEmpty()
        val icon = iconFor(pkg, n)
        val app = label(pkg, e)

        if (kind == Kind.MSG) {
            // A tracked download that finished (the same notification lost its progress bar).
            if (isl.isProgress(sbn.key)) {
                val t = (e.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
                isl.finishProgress(sbn.key, title, t, icon)
                return
            }
            if (initial || ongoing) return                 // old messages / foreground-service notices
            if (p.onlyAlerting && !alerting(sbn)) return   // respect the phone's own importance + DND

            val last = e.getParcelableArray(Notification.EXTRA_MESSAGES, Bundle::class.java)?.lastOrNull()
            var text = (last?.getCharSequence("text") ?: e.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: e.getCharSequence(Notification.EXTRA_TEXT) ?: e.getCharSequence(Notification.EXTRA_SUB_TEXT))?.toString().orEmpty()
            val sender = last?.getCharSequence("sender")?.toString()
            if (!sender.isNullOrBlank() && sender != title) text = "$sender: $text"
            if (title.isBlank() && text.isBlank()) return
            if (p.isBlocked("$title $text")) return

            val reply = acts.firstOrNull { it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY && !it.remoteInputs.isNullOrEmpty() }
                ?: acts.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
            val read = acts.firstOrNull { it.semanticAction == Notification.Action.SEMANTIC_ACTION_MARK_AS_READ }
                ?: acts.firstOrNull { it.remoteInputs.isNullOrEmpty() && it.semanticAction != Notification.Action.SEMANTIC_ACTION_REPLY }

            // Only hide the original if our island can really be shown (otherwise you'd lose the message).
            if (p.hideOriginal && Settings.canDrawOverlays(this)) cancelNotification(sbn.key)
            isl.post(Item(sbn.key, Kind.MSG, pkg, app, title.ifBlank { app }, text, icon, reply = reply, read = read, open = n.contentIntent))
            return
        }

        val text = (e.getCharSequence(Notification.EXTRA_TEXT) ?: e.getCharSequence(Notification.EXTRA_SUB_TEXT))?.toString().orEmpty()
        val chrono = if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) n.`when` else 0L
        isl.post(
            Item(
                sbn.key, kind, pkg, app, title.ifBlank { app }, text, icon,
                actions = acts, open = n.contentIntent,
                progress = e.getInt(Notification.EXTRA_PROGRESS), max = max, indeterminate = indet || (kind == Kind.PROGRESS && max <= 0),
                chrono = chrono
            )
        )
    }

    private fun alerting(sbn: StatusBarNotification): Boolean = runCatching {
        val r = NotificationListenerService.Ranking()
        if (!currentRanking.getRanking(sbn.key, r)) return@runCatching true
        r.importance >= NotificationManager.IMPORTANCE_DEFAULT && r.matchesInterruptionFilter()
    }.getOrDefault(true)

    /** Large icon (avatar / album art) -> the app's own icon -> the notification's small icon. */
    private fun iconFor(pkg: String, n: Notification): Drawable? =
        runCatching { n.getLargeIcon()?.loadDrawable(this) }.getOrNull()
            ?: runCatching { packageManager.getApplicationIcon(pkg) }.getOrNull()
            ?: runCatching { n.smallIcon?.loadDrawable(this) }.getOrNull()

    /** App name straight from the phone. */
    private fun label(pkg: String, e: Bundle): String =
        runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))).toString()
        }.getOrNull()
            ?: e.getCharSequence("android.substName")?.toString()
            ?: pkg.substringAfterLast('.')
}
