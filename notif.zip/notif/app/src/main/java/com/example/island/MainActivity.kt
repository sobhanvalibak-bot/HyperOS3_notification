package com.example.island

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0D0D12)
private val Card = Color(0xFF1A1A23)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9A9AAE)

private val DarkColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF14102B),
    background = Bg,
    surface = Bg,
    surfaceVariant = Card,
    onSurface = Color(0xFFF2F2F7),
    onBackground = Color(0xFFF2F2F7),
    outline = Color(0xFF3A3A48)
)

class MainActivity : ComponentActivity() {
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs(this)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            MaterialTheme(colorScheme = DarkColors) {
                Surface(color = Bg) { Screen(p, this@MainActivity) }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && Prefs(this).exitNotif) sendTestNotification()
    }

    private fun sendTestNotification() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("test", "Test", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val large = runCatching {
            val d = getDrawable(R.mipmap.ic_launcher)!!
            val b = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 192, 192); d.draw(Canvas(b)); b
        }.getOrNull()
        val n = Notification.Builder(this, "test")
            .setSmallIcon(R.drawable.ic_stat)
            .setLargeIcon(large)
            .setContentTitle("Test")
            .setContentText("This is a test notification from Island")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }
}

@Composable
fun Screen(p: Prefs, a: Activity) {
    Column(
        Modifier.verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(Modifier.padding(vertical = 8.dp)) {
            Text("Island", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Telegram notifications in a Dynamic Island", color = Muted, style = MaterialTheme.typography.bodyMedium)
        }

        Section("Setup") {
            Step(1, "Notification access", "Lets Island read Telegram notifications") {
                a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            Step(2, "Display over other apps", "Needed to draw the island on screen") {
                a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}")))
            }
            Step(3, "Unrestricted battery", "Keeps Island alive in the background") {
                a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            Button(
                onClick = { NotifService.inst?.island?.show(Msg("Test channel", "Hello! This is a test message.", null, null, null)) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Test island", fontWeight = FontWeight.SemiBold) }
        }

        Section("General") {
            Sw("Island enabled", null, p.enabled) { p.enabled = it }
            Sw("Always-on bar", "Empty bar that ignores touches", p.alwaysOn) { p.alwaysOn = it }
            Sw("Hide original Telegram notification", null, p.hideOriginal) { p.hideOriginal = it }
            Sw("Test notification on exit", "Shown when you leave the app", p.exitNotif) { p.exitNotif = it }
        }

        Section("Colors") {
            Col("Background", p.bg) { p.bg = it }
            Col("Text", p.fg) { p.fg = it }
            var idle by remember { mutableStateOf(p.idleText) }
            OutlinedTextField(
                idle, { idle = it; p.idleText = it },
                label = { Text("Text on idle bar") }, singleLine = true,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
            )
        }

        Section("Expanded view shows") {
            Sw("Chat / channel name", null, p.showChat) { p.showChat = it }
            Sw("Message text", null, p.showMsg) { p.showMsg = it }
            Sw("Read and Reply buttons", null, p.showBtns) { p.showBtns = it }
        }

        Section("Size & position") {
            Sl("Idle bar width", p.idleW, 40..220) { p.idleW = it }
            Sl("Idle bar height", p.idleH, 16..60) { p.idleH = it }
            Sl("Notification width", p.colW, 100..300) { p.colW = it }
            Sl("Notification height", p.colH, 24..64) { p.colH = it }
            Sl("Expanded width", p.expW, 200..420) { p.expW = it }
            Sl("Top offset", p.y, 0..60) { p.y = it }
            Sl("Corner radius (expanded)", p.radius, 8..48) { p.radius = it }
            Sl("Text size", p.textSize, 10..22) { p.textSize = it }
            Sl("Auto-hide (seconds)", p.autoHide, 2..30) { p.autoHide = it }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title.uppercase(), color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        content()
    }
}

@Composable
fun Step(n: Int, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(Accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Text("$n", color = Accent, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        FilledTonalButton(onClick, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 16.dp)) { Text("Open") }
    }
}

@Composable
fun Sw(label: String, desc: String?, init: Boolean, set: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(init) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label)
            if (desc != null) Text(desc, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        Switch(v, { v = it; set(it) })
    }
}

@Composable
fun Sl(label: String, init: Int, r: IntRange, set: (Int) -> Unit) {
    var v by remember { mutableFloatStateOf(init.toFloat()) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("${v.toInt()}", color = Accent, fontWeight = FontWeight.SemiBold)
        }
        Slider(v, { v = it; set(it.toInt()) }, valueRange = r.first.toFloat()..r.last.toFloat())
    }
}

@Composable
fun Col(label: String, init: Int, set: (Int) -> Unit) {
    var t by remember { mutableStateOf("%06X".format(init and 0xFFFFFF)) }
    fun apply(x: String) { t = x; if (x.length == 6) x.toIntOrNull(16)?.let { set(0xFF000000.toInt() or it) } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            t, { apply(it.uppercase().take(6)) },
            label = { Text("$label (HEX)") }, singleLine = true,
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("000000", "FFFFFF", "1E1E2E", "2AABEE", "7C3AED", "16A34A", "DC2626").forEach { hx ->
                Box(
                    Modifier.size(34.dp).clip(CircleShape)
                        .background(Color(0xFF000000.toInt() or hx.toInt(16)))
                        .border(if (t == hx) 2.dp else 1.dp, if (t == hx) Color.White else Color(0xFF3A3A48), CircleShape)
                        .clickable { apply(hx) }
                )
            }
        }
    }
}
