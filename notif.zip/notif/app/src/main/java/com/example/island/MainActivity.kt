package com.example.island

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.concurrent.thread
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0D0D12)
private val Card = Color(0xFF1A1A23)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9A9AAE)

private val DarkColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF14102B),
    background = Bg,
    surface = Bg,
    surfaceVariant = Card,
    onSurface = Color(0xFFF2F2F7),
    onBackground = Color(0xFFF2F2F7),
    outline = Color(0xFF3A3A48)
)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private var page by mutableIntStateOf(0)
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs(this)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            MaterialTheme(colorScheme = DarkColors) {
                BackHandler(page == 1) { page = 0 }
                Surface(color = Bg) {
                    if (page == 0) Screen(p, this@MainActivity, tick) { page = 1 }
                    else AppsScreen(p, this@MainActivity) { page = 0 }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshIsland()
        window.decorView.postDelayed({ tick++ }, 1000)
        tick++
    }

    private fun refreshIsland() {
        if (NotifService.inst == null) {
            runCatching { NotificationListenerService.requestRebind(ComponentName(this, NotifService::class.java)) }
        }
        NotifService.inst?.island?.render()
    }

    override fun onStop() {
        super.onStop()
        NotifService.inst?.island?.render()
        if (!isChangingConfigurations && Prefs(this).exitNotif) sendTestNotification()
    }

    private fun sendTestNotification() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("test", "Test", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val large = runCatching {
            val d = getDrawable(R.mipmap.ic_launcher)!!
            val b = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 192, 192); d.draw(Canvas(b)); b
        }.getOrNull()
        val n = Notification.Builder(this, "test")
            .setSmallIcon(R.drawable.ic_stat)
            .setLargeIcon(large)
            .setContentTitle("Test")
            .setContentText("This is a test notification from Island")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }
}

@Composable
fun Screen(p: Prefs, a: Activity, tick: Int, openApps: () -> Unit) {
    Column(
        Modifier.verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(Modifier.padding(vertical = 8.dp)) {
            Text("Island", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Notifications, music, calls and downloads from your phone in a Dynamic Island", color = Muted, style = MaterialTheme.typography.bodyMedium)
        }

        Section("Setup") {
            Status("Notification listener connected", tick >= 0 && NotifService.inst != null)
            Status("Display over other apps allowed", tick >= 0 && Settings.canDrawOverlays(a))
            Step(1, "Notification access", "Lets Island read notifications from all your apps") {
                a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            Step(2, "Display over other apps", "Needed to draw the island on screen") {
                a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}")))
            }
            Step(3, "Unrestricted battery", "Keeps Island alive in the background") {
                a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            val isl = NotifService.inst?.island
            fun temp(it: Item) { isl?.post(it); Handler(Looper.getMainLooper()).postDelayed({ isl?.removeKey(it.key) }, 9000) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { isl?.show(Item("t-msg", Kind.MSG, "", "Island", "Test channel", "Hello! This is a test message.", null)) },
                    modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(0.dp)
                ) { Text("Message", fontWeight = FontWeight.SemiBold) }
                Button(
                    onClick = { temp(Item("t-media", Kind.MEDIA, "", "Music", "Song title", "Artist name", null)) },
                    modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(0.dp)
                ) { Text("Music", fontWeight = FontWeight.SemiBold) }
                Button(
                    onClick = { temp(Item("t-prog", Kind.PROGRESS, "", "Downloads", "file.zip", "Downloading…", null, progress = 60, max = 100)) },
                    modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(0.dp)
                ) { Text("Download", fontWeight = FontWeight.SemiBold) }
            }
        }

        Section("Idle bar") {
            Sw("Show idle bar", "Always visible at the top, even outside the app. Ignores touches.", p.alwaysOn) { p.alwaysOn = it }
            Col("Bar color", p.idleBg) { p.idleBg = it }
            Col("Border color", p.idleBorderColor) { p.idleBorderColor = it }
            Sl("Border width", p.idleBorderW, 0..4) { p.idleBorderW = it }
            Sl("Width", p.idleW, 40..220) { p.idleW = it }
            Sl("Height", p.idleH, 16..60) { p.idleH = it }
            Sl("Roundness", p.idleRound, 0..50) { p.idleRound = it }
            var idle by remember { mutableStateOf(p.idleText) }
            OutlinedTextField(
                idle, { idle = it; p.idleText = it },
                label = { Text("Text on idle bar (optional)") }, singleLine = true,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
            )
            Col("Text color", p.idleFg) { p.idleFg = it }
        }

        Section("General") {
            Sw("Island enabled", null, p.enabled) { p.enabled = it }
            Sw("Hide original notification", "Messages only. Music, calls and downloads are never hidden.", p.hideOriginal) { p.hideOriginal = it }
            Sw("Test notification on exit", "Shown when you leave the app", p.exitNotif) { p.exitNotif = it }
        }

        Section("What to show") {
            Sw("Messages & notifications", null, p.showMsgs) { p.showMsgs = it }
            Sw("Music (now playing)", null, p.showMedia) { p.showMedia = it }
            Sw("Calls", null, p.showCalls) { p.showCalls = it }
            Sw("Downloads & progress", null, p.showProgress) { p.showProgress = it }
            Sw("Only alerting notifications", "Skips silent ones and follows Do Not Disturb, like the phone does", p.onlyAlerting) { p.onlyAlerting = it }
        }

        Section("Apps") {
            Text("All apps are on by default. Choose which apps can use the island.", color = Muted, style = MaterialTheme.typography.bodySmall)
            FilledTonalButton(openApps, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("Choose apps") }
            var terms by remember { mutableStateOf(p.blockedTerms) }
            OutlinedTextField(
                terms, { terms = it; p.blockedTerms = it },
                label = { Text("Spoiler words to ignore (comma separated)") },
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
            )
        }

        Section("Notification colors") {
            Col("Background", p.bg) { p.bg = it }
            Col("Text", p.fg) { p.fg = it }
        }

        Section("Expanded view shows") {
            Sw("Chat / channel name", null, p.showChat) { p.showChat = it }
            Sw("Message text", null, p.showMsg) { p.showMsg = it }
            Sw("Read and Reply buttons", null, p.showBtns) { p.showBtns = it }
        }

        Section("Notification size & position") {
            Sl("Collapsed width", p.colW, 100..300) { p.colW = it }
            Sl("Collapsed height", p.colH, 24..64) { p.colH = it }
            Sl("Expanded width", p.expW, 200..420) { p.expW = it }
            Sl("Top offset (also idle bar)", p.y, 0..60) { p.y = it }
            Sl("Corner radius (expanded)", p.radius, 8..48) { p.radius = it }
            Sl("Text size", p.textSize, 10..22) { p.textSize = it }
            Sl("Auto-hide (seconds)", p.autoHide, 2..30) { p.autoHide = it }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title.uppercase(), color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        content()
    }
}

@Composable
fun Status(label: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(if (ok) Color(0xFF34D399) else Color(0xFFF87171)))
        Text(label, Modifier.padding(start = 10.dp), color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Step(n: Int, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(Accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Text("$n", color = Accent, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        FilledTonalButton(onClick, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 16.dp)) { Text("Open") }
    }
}

@Composable
fun Sw(label: String, desc: String?, init: Boolean, set: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(init) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label)
            if (desc != null) Text(desc, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        Switch(v, { v = it; set(it) })
    }
}

@Composable
fun Sl(label: String, init: Int, r: IntRange, set: (Int) -> Unit) {
    var v by remember { mutableFloatStateOf(init.toFloat()) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("${v.toInt()}", color = Accent, fontWeight = FontWeight.SemiBold)
        }
        Slider(v, { v = it; set(it.toInt()) }, valueRange = r.first.toFloat()..r.last.toFloat())
    }
}

@Composable
fun Col(label: String, init: Int, set: (Int) -> Unit) {
    var t by remember { mutableStateOf("%06X".format(init and 0xFFFFFF)) }
    fun apply(x: String) { t = x; if (x.length == 6) x.toIntOrNull(16)?.let { set(0xFF000000.toInt() or it) } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            t, { apply(it.uppercase().take(6)) },
            label = { Text("$label (HEX)") }, singleLine = true,
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("000000", "FFFFFF", "1E1E2E", "2AABEE", "7C3AED", "16A34A", "DC2626").forEach { hx ->
                Box(
                    Modifier.size(34.dp).clip(CircleShape)
                        .background(Color(0xFF000000.toInt() or hx.toInt(16)))
                        .border(if (t == hx) 2.dp else 1.dp, if (t == hx) Color.White else Color(0xFF3A3A48), CircleShape)
                        .clickable { apply(hx) }
                )
            }
        }
    }
}

class AppRow(val pkg: String, val label: String)

private fun appIcon(pm: PackageManager, pkg: String): ImageBitmap? = runCatching {
    val d = pm.getApplicationIcon(pkg)
    val b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 96, 96); d.draw(Canvas(b)); b.asImageBitmap()
}.getOrNull()

@Composable
fun AppsScreen(p: Prefs, a: Activity, back: () -> Unit) {
    var apps by remember { mutableStateOf<List<AppRow>?>(null) }
    var q by remember { mutableStateOf("") }
    var ver by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        thread {
            val pm = a.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val r = pm.queryIntentActivities(i, PackageManager.ResolveInfoFlags.of(0))
                .map { AppRow(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .distinctBy { it.pkg }.filter { it.pkg != a.packageName }
                .sortedBy { it.label.lowercase() }
            Handler(Looper.getMainLooper()).post { apps = r }
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("‹ Back") }
            Text("Apps", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        }
        OutlinedTextField(q, { q = it }, label = { Text("Search") }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton({ p.disabledApps = ""; ver++ }, shape = RoundedCornerShape(12.dp)) { Text("Enable all") }
            FilledTonalButton({ p.disabledApps = apps.orEmpty().joinToString("\n") { it.pkg }; ver++ }, shape = RoundedCornerShape(12.dp)) { Text("Disable all") }
        }
        val list = apps
        if (list == null) Text("Loading…", color = Muted)
        else LazyColumn(Modifier.weight(1f)) {
            items(list.filter { q.isBlank() || it.label.contains(q, true) }, key = { it.pkg }) { app ->
                var on by remember(app.pkg, ver) { mutableStateOf(p.appEnabled(app.pkg)) }
                val ic = remember(app.pkg) { appIcon(a.packageManager, app.pkg) }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (ic != null) Image(ic, null, Modifier.size(40.dp)) else Spacer(Modifier.size(40.dp))
                    Text(app.label, Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1)
                    Switch(on, { on = it; p.setApp(app.pkg, it) })
                }
            }
        }
    }
}
