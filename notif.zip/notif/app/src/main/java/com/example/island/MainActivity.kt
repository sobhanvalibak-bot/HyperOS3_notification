package com.example.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs(this)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface { Screen(p, this) } }
            }
        }
    }
}

@Composable
fun Screen(p: Prefs, a: Activity) {
    Column(Modifier.verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Island برای تلگرام", style = MaterialTheme.typography.headlineSmall)
        Button({ a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("۱) دسترسی به نوتیف‌ها") }
        Button({ a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))) }) { Text("۲) نمایش روی سایر اپ‌ها") }
        Button({ a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("۳) بدون محدودیت باتری") }
        Button({ NotifService.inst?.island?.show(Msg("Test channel", "Hello! This is a test message.", null, null, null)) }) { Text("تست جزیره") }
        HorizontalDivider()
        Sw("جزیره روشن", p.enabled) { p.enabled = it }
        Sw("نوار همیشه روشن (خالی، بدون واکنش به لمس)", p.alwaysOn) { p.alwaysOn = it }
        Sw("مخفی کردن نوتیف اصلی تلگرام", p.hideOriginal) { p.hideOriginal = it }
        HorizontalDivider()
        Col("رنگ پس‌زمینه", p.bg) { p.bg = it }
        Col("رنگ متن", p.fg) { p.fg = it }
        var idle by remember { mutableStateOf(p.idleText) }
        OutlinedTextField(idle, { idle = it; p.idleText = it }, label = { Text("متن روی نوار خالی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        HorizontalDivider()
        Text("در حالت بزرگ نشان بده:")
        Sw("نام چت / کانال", p.showChat) { p.showChat = it }
        Sw("متن پیام", p.showMsg) { p.showMsg = it }
        Sw("دکمه‌های Read و Reply", p.showBtns) { p.showBtns = it }
        HorizontalDivider()
        Sl("عرض نوار خالی", p.idleW, 40..220) { p.idleW = it }
        Sl("ارتفاع نوار خالی", p.idleH, 16..60) { p.idleH = it }
        Sl("عرض حالت نوتیف", p.colW, 100..300) { p.colW = it }
        Sl("ارتفاع حالت نوتیف", p.colH, 24..64) { p.colH = it }
        Sl("عرض حالت بزرگ", p.expW, 200..420) { p.expW = it }
        Sl("فاصله از بالا", p.y, 0..60) { p.y = it }
        Sl("گردی گوشه‌ها (حالت بزرگ)", p.radius, 8..48) { p.radius = it }
        Sl("اندازه متن", p.textSize, 10..22) { p.textSize = it }
        Sl("بسته شدن خودکار (ثانیه)", p.autoHide, 2..30) { p.autoHide = it }
    }
}

@Composable
fun Sw(label: String, init: Boolean, set: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(init) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(v, { v = it; set(it) })
    }
}

@Composable
fun Sl(label: String, init: Int, r: IntRange, set: (Int) -> Unit) {
    var v by remember { mutableFloatStateOf(init.toFloat()) }
    Column { Text("$label: ${v.toInt()}"); Slider(v, { v = it; set(it.toInt()) }, valueRange = r.first.toFloat()..r.last.toFloat()) }
}

@Composable
fun Col(label: String, init: Int, set: (Int) -> Unit) {
    var t by remember { mutableStateOf("%06X".format(init and 0xFFFFFF)) }
    fun apply(x: String) { t = x; if (x.length == 6) x.toIntOrNull(16)?.let { set(0xFF000000.toInt() or it) } }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(t, { apply(it.uppercase().take(6)) }, label = { Text("$label (HEX)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("000000", "FFFFFF", "1E1E2E", "2AABEE", "7C3AED", "16A34A", "DC2626").forEach { hx ->
                Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF000000.toInt() or hx.toInt(16))).clickable { apply(hx) })
            }
        }
    }
}
