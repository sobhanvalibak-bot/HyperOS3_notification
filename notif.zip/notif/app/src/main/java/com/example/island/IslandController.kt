package com.example.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

enum class Kind { MSG, MEDIA, CALL, PROGRESS }

/** One thing shown in the island. Everything in here is read from the phone's notification. */
data class Item(
    val key: String,
    val kind: Kind,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val icon: Drawable?,
    val actions: List<Notification.Action> = emptyList(),
    val reply: Notification.Action? = null,
    val read: Notification.Action? = null,
    val open: PendingIntent? = null,
    val progress: Int = 0,
    val max: Int = 0,
    val indeterminate: Boolean = false,
    val done: Boolean = false,
    val chrono: Long = 0L
) {
    /** Used to skip re-drawing when a player/downloader re-posts an identical notification. */
    val sig: String get() = "$kind|$title|$text|${actions.joinToString(",") { it.title }}|${if (kind == Kind.PROGRESS) progress else 0}|$done"
}

private val GREEN = 0xFF34D399.toInt()
private val RED = 0xFFEF4444.toInt()

/** Circular progress / green tick. */
class Ring(c: Context, private val value: Float, private val col: Int, private val tick: Boolean) : View(c) {
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val s = w * 0.12f
        pa.strokeWidth = s
        val r = RectF(s, s, w - s, height - s)
        if (tick) {
            pa.color = GREEN; cv.drawArc(r, 0f, 360f, false, pa)
            val pt = Path().apply { moveTo(w * 0.3f, w * 0.52f); lineTo(w * 0.45f, w * 0.66f); lineTo(w * 0.72f, w * 0.36f) }
            cv.drawPath(pt, pa)
        } else {
            pa.color = (col and 0xFFFFFF) or (0x33 shl 24); cv.drawArc(r, 0f, 360f, false, pa)
            pa.color = col; cv.drawArc(r, -90f, 360f * value, false, pa)
        }
    }
}

class IslandController(private val c: Context) {
    private val wm = c.getSystemService(WindowManager::class.java)
    private val p = Prefs(c)
    private val h = Handler(Looper.getMainLooper())
    private val density = c.resources.displayMetrics.density
    private var root: FrameLayout? = null
    private var card: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var anim: ValueAnimator? = null

    // calls / media / downloads stay while their notification exists; messages are temporary.
    private val persistent = LinkedHashMap<String, Item>()
    private var transient: Item? = null
    private var expanded = false
    private var replying = false

    private val autoHide = Runnable {
        if (cur()?.kind == Kind.CALL) return@Runnable
        if (transient != null) dismiss() else collapse()
    }

    private fun cur(): Item? = persistent.values.lastOrNull { it.kind == Kind.CALL } ?: transient ?: persistent.values.lastOrNull()

    private fun dp(v: Int) = (v * density).toInt()
    private fun a(col: Int, alpha: Int) = (col and 0xFFFFFF) or (alpha shl 24)
    private fun rounded(col: Int, r: Int) = GradientDrawable().apply { setColor(col); cornerRadius = dp(r).toFloat() }

    // ---------- state ----------
    fun show(m: Item) = post(m)

    fun post(m: Item) {
        if (m.kind == Kind.MSG || m.done) {
            transient = m; expanded = false; replying = false
            render(); restartTimer()
        } else {
            val old = persistent[m.key]
            persistent[m.key] = m
            if (old != null && old.sig == m.sig) return
            if (old == null && m.kind == Kind.CALL) { expanded = true; replying = false; h.removeCallbacks(autoHide) }
            render()
        }
    }

    fun removeKey(key: String) {
        val old = persistent.remove(key) ?: return
        expanded = false; replying = false
        if (old.kind == Kind.PROGRESS && !old.indeterminate && old.max > 0 && old.progress * 100 / old.max >= 95) post(old.copy(done = true))
        else render()
    }

    fun isProgress(key: String) = persistent[key]?.kind == Kind.PROGRESS

    fun finishProgress(key: String, title: String, text: String, icon: Drawable?) {
        val old = persistent.remove(key) ?: return
        post(old.copy(title = title.ifBlank { old.title }, text = text, icon = icon ?: old.icon, done = true))
    }

    private fun restartTimer() { h.removeCallbacks(autoHide); h.postDelayed(autoHide, p.autoHide * 1000L) }

    fun remove() {
        h.removeCallbacksAndMessages(null)
        root?.let { runCatching { wm.removeView(it) } }
        root = null; card = null
    }

    private fun dismiss() {
        h.removeCallbacks(autoHide)
        hideIme(); focusable(false)
        transient = null; expanded = false; replying = false
        render()
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false; replying = false
        hideIme(); focusable(false); render(); restartTimer()
    }

    private fun hideIme() { c.getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(root?.windowToken, 0) }

    private fun focusable(f: Boolean) {
        val l = lp ?: return
        l.flags = if (f) l.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else l.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        root?.let { runCatching { wm.updateViewLayout(it, l) } }
    }

    private fun ensure() {
        if (root != null || !Settings.canDrawOverlays(c)) return
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        l.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        val r = FrameLayout(c)
        r.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) collapse(); false }
        val k = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        r.addView(k, FrameLayout.LayoutParams(0, 0))
        runCatching { wm.addView(r, l) }.onSuccess { root = r; card = k; lp = l }
    }

    // ---------- drawing ----------
    fun render() {
        val m = cur()
        if (!p.enabled || (m == null && !p.alwaysOn)) { remove(); return }
        ensure()
        val k = card ?: return
        val l = lp ?: return
        val st = if (m == null) 0 else if (expanded) 2 else 1   // 0 idle, 1 collapsed, 2 expanded
        val pill = st < 2
        val w = dp(listOf(p.idleW, p.colW, p.expW)[st])

        k.removeAllViews()
        k.gravity = Gravity.CENTER_VERTICAL
        k.setPadding(dp(14), if (pill) 0 else dp(12), dp(14), if (pill) 0 else dp(12))
        k.setOnClickListener(null); k.isClickable = false   // idle bar: tapping does nothing
        when (st) {
            0 -> if (p.idleText.isNotEmpty()) { k.gravity = Gravity.CENTER; k.addView(tv(p.idleText, 12f, col = p.idleFg)) }
            1 -> collapsedUi(k, m!!)
            else -> expandedUi(k, m!!)
        }

        k.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val minH = dp(if (st == 0) p.idleH else if (st == 1) p.colH else 0)
        val th = maxOf(minH, k.measuredHeight)
        k.background = GradientDrawable().apply {
            if (st == 0) {
                setColor(p.idleBg)
                if (p.idleBorderW > 0) setStroke(dp(p.idleBorderW), p.idleBorderColor)
                cornerRadius = minOf(dp(p.idleRound).toFloat(), th / 2f)
            } else {
                setColor(p.bg)
                cornerRadius = if (pill) th / 2f else dp(p.radius).toFloat()
            }
        }
        k.clipToOutline = true

        l.y = dp(p.y)
        root?.let { runCatching { wm.updateViewLayout(it, l) } }

        anim?.cancel()
        val lpk = k.layoutParams
        val fw = if (lpk.width > 0) lpk.width else w
        val fh = if (lpk.height > 0) lpk.height else th
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280; interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                val t = it.animatedValue as Float
                lpk.width = (fw + (w - fw) * t).toInt(); lpk.height = (fh + (th - fh) * t).toInt()
                k.layoutParams = lpk
            }
            start()
        }
    }

    private fun pct(m: Item) = if (m.max > 0) (m.progress * 100 / m.max).coerceIn(0, 100) else 0
    private fun indet(m: Item) = !m.done && (m.indeterminate || m.max <= 0)

    private fun collapsedUi(k: LinearLayout, m: Item) {
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        if (m.kind == Kind.PROGRESS) {
            row.addView(Ring(c, if (indet(m)) 0.25f else pct(m) / 100f, p.fg, m.done), LinearLayout.LayoutParams(dp(22), dp(22)))
            val label = if (m.done) "Done" else if (indet(m)) m.app else "${pct(m)}%"
            row.addView(tv(label, p.textSize.toFloat(), true).apply { setPadding(dp(8), 0, 0, 0) })
        } else {
            row.addView(icon(m, 24))
            val label = if (m.kind == Kind.MSG) m.app else m.title.ifBlank { m.app }
            row.addView(tv(label, p.textSize.toFloat(), true).apply { setPadding(dp(8), 0, 0, 0) })
        }
        k.addView(row)
        k.setOnClickListener {
            expanded = true
            if (m.kind == Kind.MSG) h.removeCallbacks(autoHide) else restartTimer()
            render()
        }
    }

    private fun expandedUi(k: LinearLayout, m: Item) {
        val ts = p.textSize.toFloat()
        val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        if (m.kind == Kind.PROGRESS) head.addView(Ring(c, if (indet(m)) 0.25f else pct(m) / 100f, p.fg, m.done), LinearLayout.LayoutParams(dp(32), dp(32)))
        else head.addView(icon(m, 32))

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        if (m.kind != Kind.MSG || p.showChat) col.addView(tv(m.title.ifBlank { m.app }, ts, true))
        when {
            m.kind == Kind.CALL && m.chrono > 0 -> col.addView(Chronometer(c).apply {
                base = m.chrono - System.currentTimeMillis() + SystemClock.elapsedRealtime()
                setTextColor(p.fg); alpha = 0.6f; textSize = ts - 3f; start()
            })
            m.kind == Kind.CALL -> col.addView(tv(m.text.ifBlank { m.app }, ts - 3f, false, 150))
            m.kind == Kind.MEDIA -> col.addView(tv(m.text.ifBlank { m.app }, ts - 3f, false, 150))
            else -> col.addView(tv(m.app, ts - 3f, false, 150))
        }
        head.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        m.open?.let { pi -> head.setOnClickListener { runCatching { pi.send() }; if (m.kind == Kind.MSG) dismiss() } }
        k.addView(head)

        when (m.kind) {
            Kind.MSG -> msgBody(k, m)
            Kind.MEDIA -> mediaBody(k, m)
            Kind.CALL -> callBody(k, m)
            Kind.PROGRESS -> progressBody(k, m)
        }
    }

    private fun msgBody(k: LinearLayout, m: Item) {
        if (p.showMsg && m.text.isNotBlank()) k.addView(tv(m.text, p.textSize.toFloat()).apply { maxLines = 4; setPadding(0, dp(8), 0, 0) })

        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        if (replying) {
            val et = EditText(c).apply {
                hint = "Reply…"; setTextColor(p.fg); setHintTextColor(a(p.fg, 128)); setSingleLine()
                background = rounded(a(p.fg, 0x33), 14); setPadding(dp(12), dp(8), dp(12), dp(8))
                textSize = p.textSize.toFloat(); imeOptions = EditorInfo.IME_ACTION_SEND
                setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { send(m, text.toString()); true } else false }
            }
            row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
            row.addView(btn("Send") { send(m, et.text.toString()) })
            et.postDelayed({ et.requestFocus(); c.getSystemService(InputMethodManager::class.java).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT) }, 150)
            k.addView(row)
        } else if (p.showBtns) {
            val lpb = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) } }
            if (m.open != null) row.addView(btn("Open") { runCatching { m.open.send() }; dismiss() }, lpb())
            if (m.read != null) row.addView(btn("Read") { runCatching { m.read.actionIntent?.send() }; dismiss() }, lpb())
            if (m.reply != null) row.addView(btn("Reply") { replying = true; focusable(true); render() }, lpb())
            if (row.childCount > 0) k.addView(row)
        }
    }

    private fun mediaBody(k: LinearLayout, m: Item) {
        if (m.actions.isEmpty()) return
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        m.actions.take(5).forEach { act ->
            val d = runCatching { act.getIcon()?.loadDrawable(c) }.getOrNull()
            val v: View = if (d != null) ImageView(c).apply {
                setImageDrawable(d); setColorFilter(p.fg)
                setPadding(dp(11), dp(11), dp(11), dp(11)); background = rounded(a(p.fg, 0x22), 24)
                setOnClickListener { runCatching { act.actionIntent?.send() } }
            } else btn(act.title.toString()) { runCatching { act.actionIntent?.send() } }
            val size = if (d != null) dp(48) else ViewGroup.LayoutParams.WRAP_CONTENT
            row.addView(v, LinearLayout.LayoutParams(size, size).apply { marginStart = dp(5); marginEnd = dp(5) })
        }
        k.addView(row)
    }

    private fun callBody(k: LinearLayout, m: Item) {
        if (m.actions.isEmpty()) return
        val acts = m.actions.take(3)
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        acts.forEachIndexed { i, act ->
            val bg = when {
                acts.size == 1 -> RED
                acts.size == 2 -> if (i == 0) RED else GREEN
                else -> a(p.fg, 0x33)
            }
            val b = btn(act.title.toString()) { runCatching { act.actionIntent?.send() } }.apply { background = rounded(bg, 22) }
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        }
        k.addView(row)
    }

    private fun progressBody(k: LinearLayout, m: Item) {
        if (m.text.isNotBlank()) k.addView(tv(m.text, p.textSize - 1f, false, 200).apply { setPadding(0, dp(8), 0, 0) })
        val ind = indet(m)
        val pb = ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = ind
            if (!ind) { max = if (m.done) 100 else m.max; progress = if (m.done) 100 else m.progress }
            progressTintList = ColorStateList.valueOf(if (m.done) GREEN else p.fg)
            progressBackgroundTintList = ColorStateList.valueOf(a(p.fg, 0x33))
            indeterminateTintList = ColorStateList.valueOf(p.fg)
        }
        k.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)).apply { topMargin = dp(10) })
    }

    private fun send(m: Item, t: String) {
        if (t.isBlank()) return
        val act = m.reply
        val ri = act?.remoteInputs
        if (act != null && !ri.isNullOrEmpty()) {
            val i = Intent(); val b = Bundle()
            b.putCharSequence(ri[0].resultKey, t)
            RemoteInput.addResultsToIntent(ri, i, b)
            runCatching { act.actionIntent.send(c, 0, i) }
        }
        dismiss()
    }

    private fun tv(t: String, size: Float, bold: Boolean = false, alpha: Int = 255, col: Int = p.fg) = TextView(c).apply {
        text = t; setTextColor(col); this.alpha = alpha / 255f; textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
    }

    private fun btn(t: String, f: () -> Unit) = tv(t, p.textSize.toFloat(), true).apply {
        gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(9))
        background = rounded(a(p.fg, 0x33), 14); setOnClickListener { f() }
    }

    private fun icon(m: Item, s: Int) = ImageView(c).apply {
        setImageDrawable(m.icon); scaleType = ImageView.ScaleType.CENTER_CROP
        setBackgroundColor(a(p.fg, 0x22))
        layoutParams = LinearLayout.LayoutParams(dp(s), dp(s))
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) } }
    }
}
