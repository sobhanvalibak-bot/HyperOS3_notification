package com.example.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

class Msg(val chat: String, val text: String, val icon: Drawable?, val reply: Notification.Action?, val read: Notification.Action?)

class IslandController(private val c: Context) {
    private val wm = c.getSystemService(WindowManager::class.java)
    private val p = Prefs(c)
    private val h = Handler(Looper.getMainLooper())
    private val density = c.resources.displayMetrics.density
    private var root: FrameLayout? = null
    private var card: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var anim: ValueAnimator? = null
    private var msg: Msg? = null
    private var expanded = false
    private var replying = false
    private val autoHide = Runnable { dismiss() }

    private fun dp(v: Int) = (v * density).toInt()
    private fun a(col: Int, alpha: Int) = (col and 0xFFFFFF) or (alpha shl 24)
    private fun rounded(col: Int, r: Int) = GradientDrawable().apply { setColor(col); cornerRadius = dp(r).toFloat() }

    fun show(m: Msg) {
        msg = m; expanded = false; replying = false
        render(); restartTimer()
    }

    private fun restartTimer() { h.removeCallbacks(autoHide); h.postDelayed(autoHide, p.autoHide * 1000L) }

    fun remove() {
        h.removeCallbacksAndMessages(null)
        root?.let { runCatching { wm.removeView(it) } }
        root = null; card = null
    }

    private fun dismiss() {
        h.removeCallbacks(autoHide)
        hideIme(); focusable(false)
        msg = null; expanded = false; replying = false
        render()
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false; replying = false
        hideIme(); focusable(false); render(); restartTimer()
    }

    private fun hideIme() { c.getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(root?.windowToken, 0) }

    private fun focusable(f: Boolean) {
        val l = lp ?: return
        l.flags = if (f) l.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else l.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        root?.let { runCatching { wm.updateViewLayout(it, l) } }
    }

    private fun ensure() {
        if (root != null || !Settings.canDrawOverlays(c)) return
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        l.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        val r = FrameLayout(c)
        r.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) collapse(); false }
        val k = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        r.addView(k, FrameLayout.LayoutParams(0, 0))
        runCatching { wm.addView(r, l) }.onSuccess { root = r; card = k; lp = l }
    }

    fun render() {
        if (!p.enabled || (msg == null && !p.alwaysOn)) { remove(); return }
        ensure()
        val k = card ?: return
        val l = lp ?: return
        val m = msg
        val st = if (m == null) 0 else if (expanded) 2 else 1   // 0 idle, 1 collapsed, 2 expanded
        val pill = st < 2
        val w = dp(listOf(p.idleW, p.colW, p.expW)[st])

        k.removeAllViews()
        k.gravity = Gravity.CENTER_VERTICAL
        k.setPadding(dp(14), if (pill) 0 else dp(12), dp(14), if (pill) 0 else dp(12))
        k.setOnClickListener(null); k.isClickable = false   // idle bar: tapping does nothing
        when (st) {
            0 -> if (p.idleText.isNotEmpty()) { k.gravity = Gravity.CENTER; k.addView(tv(p.idleText, 12f, col = p.idleFg)) }
            1 -> {
                val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
                row.addView(icon(m!!, 24))
                row.addView(tv("Telegram", p.textSize.toFloat(), true).apply { setPadding(dp(8), 0, 0, 0) })
                k.addView(row)
                k.setOnClickListener { expanded = true; h.removeCallbacks(autoHide); render() }
            }
            else -> expandedUi(k, m!!)
        }

        k.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val minH = dp(if (st == 0) p.idleH else if (st == 1) p.colH else 0)
        val th = maxOf(minH, k.measuredHeight)
        k.background = GradientDrawable().apply {
            if (st == 0) {
                setColor(p.idleBg)
                if (p.idleBorderW > 0) setStroke(dp(p.idleBorderW), p.idleBorderColor)
                cornerRadius = minOf(dp(p.idleRound).toFloat(), th / 2f)
            } else {
                setColor(p.bg)
                cornerRadius = if (pill) th / 2f else dp(p.radius).toFloat()
            }
        }
        k.clipToOutline = true

        l.y = dp(p.y)
        root?.let { runCatching { wm.updateViewLayout(it, l) } }

        anim?.cancel()
        val lpk = k.layoutParams
        val fw = if (lpk.width > 0) lpk.width else w
        val fh = if (lpk.height > 0) lpk.height else th
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280; interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                val t = it.animatedValue as Float
                lpk.width = (fw + (w - fw) * t).toInt(); lpk.height = (fh + (th - fh) * t).toInt()
                k.layoutParams = lpk
            }
            start()
        }
    }

    private fun expandedUi(k: LinearLayout, m: Msg) {
        val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(icon(m, 32))
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        if (p.showChat) col.addView(tv(m.chat, p.textSize.toFloat(), true))
        col.addView(tv("Telegram", p.textSize - 3f, false, 150))
        head.addView(col); k.addView(head)
        if (p.showMsg) k.addView(tv(m.text, p.textSize.toFloat()).apply { maxLines = 4; setPadding(0, dp(8), 0, 0) })

        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        if (replying) {
            val et = EditText(c).apply {
                hint = "Reply…"; setTextColor(p.fg); setHintTextColor(a(p.fg, 128)); setSingleLine()
                background = rounded(a(p.fg, 0x33), 14); setPadding(dp(12), dp(8), dp(12), dp(8))
                textSize = p.textSize.toFloat(); imeOptions = EditorInfo.IME_ACTION_SEND
                setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { send(m, text.toString()); true } else false }
            }
            row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
            row.addView(btn("Send") { send(m, et.text.toString()) })
            et.postDelayed({ et.requestFocus(); c.getSystemService(InputMethodManager::class.java).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT) }, 150)
            k.addView(row)
        } else if (p.showBtns) {
            val lpb = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) } }
            row.addView(btn("Read") { m.read?.let { runCatching { it.actionIntent.send() } }; dismiss() }, lpb())
            row.addView(btn("Reply") { replying = true; focusable(true); render() }, lpb())
            k.addView(row)
        }
    }

    private fun send(m: Msg, t: String) {
        if (t.isBlank()) return
        val act = m.reply
        val ri = act?.remoteInputs
        if (act != null && !ri.isNullOrEmpty()) {
            val i = Intent(); val b = Bundle()
            b.putCharSequence(ri[0].resultKey, t)
            RemoteInput.addResultsToIntent(ri, i, b)
            runCatching { act.actionIntent.send(c, 0, i) }
        }
        dismiss()
    }

    private fun tv(t: String, size: Float, bold: Boolean = false, alpha: Int = 255, col: Int = p.fg) = TextView(c).apply {
        text = t; setTextColor(col); this.alpha = alpha / 255f; textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
    }

    private fun btn(t: String, f: () -> Unit) = tv(t, p.textSize.toFloat(), true).apply {
        gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(9))
        background = rounded(a(p.fg, 0x33), 14); setOnClickListener { f() }
    }

    private fun icon(m: Msg, s: Int) = ImageView(c).apply {
        setImageDrawable(m.icon); scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = LinearLayout.LayoutParams(dp(s), dp(s))
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) } }
    }
}
